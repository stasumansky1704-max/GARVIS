// =============================================================================
// GARVIS — Operator Governance Console
// Main Application with View Switching (not page routing)
// =============================================================================

import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import Navigation from "./components/Navigation";
import StatusBar from "./components/StatusBar";
import GovernancePanel from "./components/GovernancePanel";
import StateMachinePanel from "./components/StateMachinePanel";
import CognitionStream from "./components/CognitionStream";
import AuditFeed from "./components/AuditFeed";
import MemoryExplorer from "./components/MemoryExplorer";
import TraceViewer from "./components/TraceViewer";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import PressureMap from "./components/PressureMap";
import ContinuityTimeline from "./components/ContinuityTimeline";
import EcosystemGraph from "./components/EcosystemGraph";
import AlertPanel from "./components/AlertPanel";
import TopologyView from "./components/TopologyView";
import { useWebSocket } from "./hooks/useWebSocket";
import { useApi } from "./hooks/useApi";
import { api } from "./api";
import type { ConsoleView, AuditEvent } from "./types";

// =============================================================================
// Overview View — Combined summary of key metrics
// =============================================================================

const OverviewView: React.FC = () => {
  const { data: overview } = useApi(api.analytics.getOverview);
  const { data: state } = useApi(api.cognition.getState);
  const { data: schemas } = useApi(api.governance.getSchemas);

  const g = overview?.governance;
  const c = overview?.cognition;
  const m = overview?.memory;
  const t = overview?.traceability;
  const cont = overview?.continuity;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--gap)", height: "100%", overflowY: "auto" }}>
      {/* Top Row: Key Status Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "var(--gap)" }}>
        <div className="metric-card">
          <div className="metric-label">System State</div>
          <div className="metric-value" style={{ color: state?.state === "governed" ? "#ff33ff" : "#33ff33", fontSize: 18 }}>
            {(state?.state ?? "—").toUpperCase()}
          </div>
          <div className="metric-sub">{state?.transitions_today ?? 0} transitions today</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Active Schemas</div>
          <div className="metric-value" style={{ color: "#ff33ff" }}>{schemas?.filter((s) => s.active).length ?? 0}</div>
          <div className="metric-sub">of {schemas?.length ?? 0} total</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Coverage</div>
          <div className="metric-value" style={{ color: g && g.coverage_score > 0.9 ? "#33ff33" : "#ffaa00" }}>
            {g ? `${(g.coverage_score * 100).toFixed(0)}%` : "—"}
          </div>
          <div className="metric-sub">target: 95%</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Success Rate</div>
          <div className="metric-value" style={{ color: c && c.success_rate > 0.95 ? "#33ff33" : "#ffaa00" }}>
            {c ? `${(c.success_rate * 100).toFixed(0)}%` : "—"}
          </div>
          <div className="metric-sub">{c?.session_count ?? 0} sessions</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Memories</div>
          <div className="metric-value" style={{ color: "#00ffff" }}>
            {m?.total_memories.toLocaleString() ?? "—"}
          </div>
          <div className="metric-sub">{m?.influences_tracked ?? 0} influences</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Continuity</div>
          <div className="metric-value" style={{ color: cont && cont.continuity_score > 0.85 ? "#33ff33" : "#ffaa00" }}>
            {cont ? `${(cont.continuity_score * 100).toFixed(0)}%` : "—"}
          </div>
          <div className="metric-sub">drift: {cont ? `${(cont.alignment_drift * 100).toFixed(1)}%` : "—"}</div>
        </div>
      </div>

      {/* Middle Row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "var(--gap)", flex: 1, minHeight: 0 }}>
        {/* Recent Events */}
        <div className="panel" style={{ overflow: "hidden" }}>
          <div className="panel-header">
            <span className="panel-title">Recent Audit Events</span>
          </div>
          <div className="panel-body" style={{ overflowY: "auto" }}>
            <div className="stream-feed">
              {[
                { event_id: "AUD-003", severity: "critical", event_type: "governance_check", component: "governance", timestamp: "2025-01-15T09:24:15Z", message: "Policy violation: Harm Boundary POL-015 triggered" },
                { event_id: "AUD-004", severity: "warning", event_type: "violation_blocked", component: "governance", timestamp: "2025-01-15T09:24:15Z", message: "Output blocked by Harm Boundary schema" },
                { event_id: "AUD-008", severity: "warning", event_type: "governance_check", component: "governance", timestamp: "2025-01-15T09:25:10Z", message: "Self-reflection loop lagging: 340ms delay" },
                { event_id: "AUD-009", severity: "warning", event_type: "schema_conflict", component: "governance", timestamp: "2025-01-15T09:25:15Z", message: "Schema conflict: Session Integrity vs Temporal Coherence" },
                { event_id: "AUD-012", severity: "warning", event_type: "continuity_alert", component: "continuity", timestamp: "2025-01-15T09:25:25Z", message: "Alignment drift detected: 0.12 exceeds threshold 0.10" },
              ].slice(0, 8).map((evt: any) => (
                <div key={evt.event_id} className="stream-entry">
                  <span className="stream-timestamp">{evt.timestamp.slice(11, 19)}</span>
                  <span className="stream-badge">
                    <span
                      className="badge badge-sm"
                      style={{
                        borderColor: evt.severity === "critical" ? "#ff3333" : evt.severity === "warning" ? "#ffaa00" : "#3388ff",
                        color: evt.severity === "critical" ? "#ff3333" : evt.severity === "warning" ? "#ffaa00" : "#3388ff",
                        background: evt.severity === "critical" ? "rgba(255,51,51,0.1)" : evt.severity === "warning" ? "rgba(255,170,0,0.1)" : "rgba(51,136,255,0.1)",
                      }}
                    >
                      {evt.severity.toUpperCase()}
                    </span>
                  </span>
                  <span className="stream-message" style={{ color: "#ccc" }}>
                    {evt.message ?? evt.event_type}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Traceability Summary */}
        <div className="panel" style={{ overflow: "hidden" }}>
          <div className="panel-header">
            <span className="panel-title">Traceability Overview</span>
          </div>
          <div className="panel-body" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "var(--gap)" }}>
              <div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textTransform: "uppercase" }}>Total Traces</div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, color: "#3388ff", fontWeight: 700 }}>{t?.total_traces ?? 0}</div>
              </div>
              <div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textTransform: "uppercase" }}>Violations</div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, color: t && t.violation_count > 0 ? "#ff3333" : "#33ff33", fontWeight: 700 }}>{t?.violation_count ?? 0}</div>
              </div>
              <div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textTransform: "uppercase" }}>Avg Checks/Trace</div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, color: "#e0e0e0", fontWeight: 700 }}>{t?.avg_governance_checks.toFixed(1) ?? "—"}</div>
              </div>
              <div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textTransform: "uppercase" }}>Audit Events</div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, color: "#8888aa", fontWeight: 700 }}>{t?.audit_event_count.toLocaleString() ?? 0}</div>
              </div>
            </div>

            {/* Mini trend */}
            {overview && (
              <svg viewBox="0 0 100 30" style={{ width: "100%", height: 60 }} preserveAspectRatio="none">
                {overview.trends.quality_trend.map((p, i, arr) => {
                  if (i === 0) return null;
                  const x1 = ((i - 1) / (arr.length - 1)) * 100;
                  const x2 = (i / (arr.length - 1)) * 100;
                  const y1 = 30 - arr[i - 1].value * 25;
                  const y2 = 30 - p.value * 25;
                  return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#3388ff" strokeWidth={1} />;
                })}
              </svg>
            )}
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textAlign: "center" }}>
              Quality Trend (24h)
            </div>

            {/* Ecosystem summary */}
            <div style={{ borderTop: "1px solid #2a2a4a", paddingTop: 8 }}>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: "#666", textTransform: "uppercase", marginBottom: 4 }}>
                Ecosystem
              </div>
              <div style={{ display: "flex", gap: 16, fontFamily: "var(--font-mono)", fontSize: 10 }}>
                <span style={{ color: "#ff33ff" }}>Gov: {overview?.ecosystem.governance_nodes ?? 0}</span>
                <span style={{ color: "#00ffff" }}>Mem: {overview?.ecosystem.memory_nodes ?? 0}</span>
                <span style={{ color: "#3388ff" }}>Reas: {overview?.ecosystem.reasoning_nodes ?? 0}</span>
                <span style={{ color: "#8888aa" }}>Edges: {overview?.ecosystem.total_edges ?? 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: Pressure */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "var(--gap)" }}>
        {[
          { label: "Adaptation Pressure", value: overview?.pressure.adaptation_pressure ?? 0, color: "#3388ff" },
          { label: "Enforcement Pressure", value: overview?.pressure.enforcement_pressure ?? 0, color: "#ff3333" },
          { label: "Conflict Pressure", value: overview?.pressure.conflict_pressure ?? 0, color: "#ffaa00" },
          { label: "Overall Pressure", value: overview?.pressure.overall_pressure ?? 0, color: "#33ff33" },
        ].map((p) => (
          <div key={p.label} className="metric-card" style={{ padding: "8px 12px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span className="metric-label" style={{ fontSize: 8 }}>{p.label}</span>
              <span className="metric-value" style={{ color: p.color, fontSize: 16 }}>{(p.value * 100).toFixed(0)}%</span>
            </div>
            {/* Mini bar */}
            <div style={{ width: "100%", height: 4, background: "#2a2a4a", marginTop: 6 }}>
              <div style={{ width: `${p.value * 100}%`, height: 4, background: p.color }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// =============================================================================
// Governance View
// =============================================================================

const GovernanceView: React.FC = () => {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "var(--gap)", height: "100%" }}>
      <GovernancePanel />
      <StateMachinePanel />
    </div>
  );
};

// =============================================================================
// Cognition View
// =============================================================================

const CognitionView: React.FC = () => {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "var(--gap)", height: "100%" }}>
      <CognitionStream />
      <StateMachinePanel />
    </div>
  );
};

// =============================================================================
// App Component
// =============================================================================

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ConsoleView>("overview");
  const { connected: wsConnected } = useWebSocket({ autoConnect: true, messageTypes: ["audit", "cognition", "state_change"] });
  const { data: opState } = useApi(api.cognition.getState);
  const { data: auditEvents } = useApi(api.audit.getEvents);

  const criticalCount = (auditEvents || []).filter((e) => e.severity === "critical").length;

  const renderView = () => {
    switch (activeView) {
      case "overview": return <OverviewView />;
      case "governance": return <GovernanceView />;
      case "cognition": return <CognitionView />;
      case "memory": return <MemoryExplorer />;
      case "traceability": return <TraceViewer />;
      case "audit": return <AuditFeed />;
      case "analytics": return <AnalyticsDashboard />;
      case "ecosystem": return (
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "var(--gap)", height: "100%" }}>
          <PressureMap />
          <ContinuityTimeline />
          <EcosystemGraph />
        </div>
      );
      case "alerts": return <AlertPanel />;
      case "topology": return <TopologyView />;
      default: return <OverviewView />;
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", width: "100vw", overflow: "hidden" }}>
      {/* Header */}
      <Header
        currentState={opState?.state ?? "unknown"}
        alertCount={criticalCount}
        connectionStatus={wsConnected ? "connected" : "disconnected"}
      />

      {/* Main Content */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* Navigation Sidebar */}
        <Navigation activeView={activeView} onViewChange={setActiveView} />

        {/* View Content */}
        <main
          style={{
            flex: 1,
            padding: "var(--gap)",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {renderView()}
        </main>
      </div>

      {/* Status Bar */}
      <StatusBar wsConnected={wsConnected} />
    </div>
  );
};

export default App;
